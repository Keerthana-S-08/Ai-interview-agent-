# AI Interview Agent

A personalized, multi-turn technical interview system for ABTalks Problem Statement 2.

## What it satisfies

- Conversational technical interview
- Minimum 8 questions
- Coverage of at least 4 curriculum days when the candidate profile permits it
- Questions restricted to passed curriculum missions
- Adaptive follow-up / new-topic selection
- Session state maintained by the supplied `sessionId`
- Structured final feedback with `summary`, `strengths`, `gaps`, and `next`
- Official curriculum and candidate JSON included
- Single required backend endpoint: `POST /api/interview`
- No authentication, persistent accounts, or voice required

## Architecture

React/Vite frontend → FastAPI backend → Gemini LLM → curriculum + candidate profile → interview state → feedback.

## Local setup

### 1. Backend

```bash
cd backend
python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# Windows CMD
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env
```

Put your Gemini API key in `backend/.env`:

```env
GEMINI_API_KEY=your_key
GEMINI_MODEL=gemini-2.5-flash
```

Run:

```bash
uvicorn app.main:app --reload --port 8000
```

### 2. Frontend

Open a second terminal:

```bash
cd frontend
npm install
copy .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal, usually `http://localhost:5173`.

## API contract

The only agent endpoint is:

`POST /api/interview`

Start:

```json
{
  "sessionId": "abc-123",
  "candidate": { "...candidate profile..." }
}
```

Turn:

```json
{
  "sessionId": "abc-123",
  "message": "The candidate's answer"
}
```

Final:

```json
{
  "reply": "Thank you. That completes the technical interview.",
  "done": true,
  "feedback": {
    "summary": "...",
    "strengths": ["..."],
    "gaps": ["..."],
    "next": ["..."]
  }
}
```

## Important hackathon practice

Keep development commits small and honest:

```bash
git add .
git commit -m "chore: initialize project"
git commit -m "feat: add candidate selection"
git commit -m "feat: implement interview session API"
git commit -m "feat: add adaptive question generation"
git commit -m "feat: add structured feedback"
git commit -m "style: polish interview UI"
```

Create `PROMPTS.md` and record the AI prompts you actually use during development. Do not fabricate a prompt history.

## Deployment

Recommended:
- Frontend: Vercel
- Backend: Render

Set frontend environment variable:

`VITE_API_URL=https://YOUR-BACKEND.onrender.com`

Set backend environment variable:

`GEMINI_API_KEY=...`

Never commit `.env` or API keys.
