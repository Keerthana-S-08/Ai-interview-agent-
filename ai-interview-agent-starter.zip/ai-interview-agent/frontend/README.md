# AI Interview Agent — Frontend

React + Vite frontend for ABTalks Problem Statement 2.

## Run

```bash
npm install
npm run dev
```

Set `VITE_API_URL` in `.env` to your backend URL if it is not running on `http://127.0.0.1:8000`.
